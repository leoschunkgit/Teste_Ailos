﻿using System.Globalization;
using System.Transactions;

namespace Questao1
{
    public class ContaBancaria {

        public int numero { get; set; }
        public string titular { get; set; }
        public double? depositoInicial { get; set; }
        public double saldo {  get; set; }
               
                
        public ContaBancaria(int Numero, string Titular, double DepositoInicial)
        {
            numero = Numero;   
            titular = Titular; 
            depositoInicial = DepositoInicial;
            saldo = DepositoInicial;
        }

        public ContaBancaria(int Numero, string Titular)
        {
            numero = Numero;
            titular = Titular;
        }        

        public void Deposito(double Quantia)
        {
            saldo += Quantia;
        }

        public void Saque(double Quantia)
        {
            double taxaSaque = 3.5;
            saldo = saldo - Quantia - taxaSaque;
        }
    }
}
