﻿using Newtonsoft.Json;
using Questao2;
using System.ComponentModel;
using System.Net.Http.Headers;

public class Program
{
    public static int totalPagina;

    public static void Main()
    {
        getTotalScoredGoals("Paris Saint-Germain", 2013).Wait();
        getTotalScoredGoals("Chelsea", 2014).Wait();

        // Output expected:
        // Team Paris Saint - Germain scored 109 goals in 2013
        // Team Chelsea scored 92 goals in 2014
    }    

    public static async Task getTotalScoredGoals(string team, int year)
    {
        var gols = 0;

        try
        {
            using (var client = new HttpClient())
            {
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                HttpResponseMessage responseTeamUm = await client.GetAsync($"https://jsonmock.hackerrank.com/api/football_matches?year={year}&team1={team}");
                
                if (responseTeamUm.IsSuccessStatusCode)
                {
                    var responseJson = await responseTeamUm.Content.ReadAsStringAsync();
                    var result = JsonConvert.DeserializeObject<football_matches>(responseJson);

                    if (result == null) throw new Exception("Erro do retorno do Json.");

                    gols = result.data.Sum(x => x.team1goals);

                    for (int i = 2; i <= result.total_pages; i++)
                    {
                        HttpResponseMessage responsePorPagina = await client.GetAsync($"https://jsonmock.hackerrank.com/api/football_matches?year={year}&team1={team}&page={i}");

                        var _responseJsonPorPagina = await responsePorPagina.Content.ReadAsStringAsync();
                        var _resultPorPagina = JsonConvert.DeserializeObject<football_matches>(_responseJsonPorPagina);

                        if (_resultPorPagina == null) throw new Exception("Erro ao trazer o dados da página.");

                        gols = gols + _resultPorPagina.data.Sum(x => x.team1goals);
                    }

                }

                HttpResponseMessage responseTeamDois = await client.GetAsync($"https://jsonmock.hackerrank.com/api/football_matches?year={year}&team2={team}");
                if (responseTeamDois.IsSuccessStatusCode)
                {
                    var responseJson = await responseTeamDois.Content.ReadAsStringAsync();
                    var result = JsonConvert.DeserializeObject<football_matches>(responseJson);

                    if (result == null) throw new Exception("Erro do retorno do Json.");

                    gols = gols + result.data.Sum(x => x.team2goals);

                    for (int i = 2; i <= result.total_pages; i++)
                    {
                        HttpResponseMessage responsePorPagina = await client.GetAsync($"https://jsonmock.hackerrank.com/api/football_matches?year={year}&team2={team}&page={i}");

                        var _responseJsonPorPagina = await responsePorPagina.Content.ReadAsStringAsync();
                        var _resultPorPagina = JsonConvert.DeserializeObject<football_matches>(_responseJsonPorPagina);

                        if (_resultPorPagina == null) throw new Exception("Erro ao trazer o dados da página.");

                        gols = gols + _resultPorPagina.data.Sum(x => x.team2goals);
                    }

                }

                Console.WriteLine(string.Concat("Team:", team, " / Scored:", gols, " goals", " in ", year));
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine("ERRO: " + ex.Message);
        }
    } 

}

        
