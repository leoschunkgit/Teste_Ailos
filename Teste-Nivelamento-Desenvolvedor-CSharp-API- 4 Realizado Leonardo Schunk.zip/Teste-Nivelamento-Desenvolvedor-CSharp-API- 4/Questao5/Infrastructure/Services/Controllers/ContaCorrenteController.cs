﻿using MediatR;
using Microsoft.AspNetCore.Mvc;
using Questao5.Application.Commands.Requests;
using Questao5.Application.Commands.Responses;
using Questao5.Application.Queries;
using Questao5.Application.Queries.Requests;
using Questao5.Application.Queries.Responses;
using SQLitePCL;
using System.Net;

namespace Questao5.Infrastructure.Services.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class ContaCorrenteController : ControllerBase
    {
        private readonly ILogger<ContaCorrenteController> _logger;
        private readonly IMediator _mediator;   
        
        public ContaCorrenteController(ILogger<ContaCorrenteController> logger, IMediator mediator)
        {
            _logger = logger;
            _mediator = mediator;               
        }

        [HttpPost]        
        public async Task<IActionResult> CadastrarMovimentacao([FromBody] CadastrarMovimentoCommandRequest command)
        {
            var response = await _mediator.Send(command);
            return Ok(response);
        }

        [HttpGet("{idContaCorrente}")]
        public async Task<IActionResult> GetSaldoContaCorrente([FromRoute] Guid idContaCorrente)
        {
            var result = await _mediator.Send(new SaldoContaCorrenteRequest(idContaCorrente));
            return Ok(result);
        }
    }
}
