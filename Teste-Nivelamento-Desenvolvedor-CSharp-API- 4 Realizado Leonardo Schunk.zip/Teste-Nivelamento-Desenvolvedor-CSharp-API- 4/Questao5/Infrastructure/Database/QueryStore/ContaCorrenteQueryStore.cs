﻿using Dapper;
using Microsoft.Data.Sqlite;
using Questao5.Application.Queries;
using Questao5.Infrastructure.Sqlite;
using System.Data;
using System.Data.SqlClient;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;

namespace Questao5.Infrastructure.Database.QueryStore
{
    public class ContaCorrenteQueryStore : IContaCorrenteQueryStore
    {   
        private readonly IConfiguration _configuration;
        
        public ContaCorrenteQueryStore(IConfiguration configuration)
        {   
            _configuration = configuration;
        }

        public string GetConnection()
        {
            var con = _configuration.GetSection("DatabaseName").Value;
            return con;
        }

        public async Task<string> VerificarIdContaCorrentePorIdAsync(Guid idcontacorrente)
        {   
            using var connection = new SqliteConnection(GetConnection());

            await connection.OpenAsync();

            var parameters = new
            {
                pr_idcontacorrente = idcontacorrente.ToString().ToUpper()
            };

            var resultadoConsulta = await connection
                .QuerySingleOrDefaultAsync<string>
                (
                    SQL_VERIFICAR_ID_CONTA_CORRENTE,
                    parameters
                );

            if (connection.State == ConnectionState.Open)
            {
                await connection.CloseAsync();
            }

            return resultadoConsulta;
        }

        private const string SQL_VERIFICAR_ID_CONTA_CORRENTE =
            @"select 
                    cc.idcontacorrente 
                from contacorrente cc
                where cc.idcontacorrente = :pr_idcontacorrente;";



        public async Task<string> VerificarIdContaCorrentePorIdAndAtivoAsync(Guid idcontacorrente)
        {   
            using var connection = new SqliteConnection(GetConnection());
            await connection.OpenAsync();

            var parameters = new
            {
                pr_idcontacorrente = idcontacorrente.ToString().ToUpper()
            };

            var resultconsulta = await connection
                .QuerySingleOrDefaultAsync<string>
                (
                    SQL_BUSCAR_CONTA_CORRENTE_POR_ID,
                    parameters
                );

            return resultconsulta;
        }

        private const string SQL_BUSCAR_CONTA_CORRENTE_POR_ID =
            @"select 
                    cc.idcontacorrente
                from contacorrente cc
                where cc.idcontacorrente = :pr_idcontacorrente and cc.ativo = 1;";
    }
}
