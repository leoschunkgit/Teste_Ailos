﻿using Dapper;
using Microsoft.Data.Sqlite;
using Questao5.Application.Queries;
using Questao5.Application.Queries.Requests;
using System.Data;
using System.Data.SqlClient;

namespace Questao5.Infrastructure.Database.QueryStore
{
    public class MovimentoQueryStore : IMovimentoQueryStore
    {
        private readonly IConfiguration _configuration;

        public MovimentoQueryStore(IConfiguration configuration)
        {
            _configuration = configuration;                   
        }

        public string GetConnection()
        {
            var con = _configuration.GetSection("DatabaseName").Value;
            return con;
        }

        public async Task<List<MovimentoDTO>> BuscarSaldoContaCorrenteAsync(SaldoContaCorrenteRequest request)
        {
            using var connection = new SqliteConnection(GetConnection());

            await connection.OpenAsync();

            var parameters = new
            {
                pr_idcontacorrente = request.idContaCorrente.ToString().ToUpper()
            };

            var resultconsulta = await connection
                .QueryAsync<MovimentoDTO>
                (
                    SQL_SALDO_CONTA_CORRENTE_POR_ID,
                    parameters
                );

            if (connection.State == ConnectionState.Open)
            {
                await connection.CloseAsync();
            }

            return resultconsulta.ToList();
        }

        private const string SQL_SALDO_CONTA_CORRENTE_POR_ID =
            @"select 
                        cc.ativo as contaCorrenteAtivo,
                        cc.numero as numeroContaCorrente,
                        cc.nome as nomeTitularContaCorrente,
                        m.tipomovimento as tipomovimento,
                        m.valor as valor	
                    from movimento m	            
	            inner join contacorrente cc on m.idcontacorrente = cc.idcontacorrente 
                where m.idcontacorrente = :pr_idcontacorrente";

                
    }
}
