﻿using Dapper;
using Microsoft.Data.Sqlite;
using Questao5.Domain.Entities;
using Questao5.Domain.Entities.Movimentacao;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;

namespace Questao5.Infrastructure.Database.CommandStore
{
    public class MovimentoCommandStore : IMovimentoCommandStore
    {
        private readonly IConfiguration _configuration;

        public MovimentoCommandStore(IConfiguration configuration)
        {
            _configuration = configuration;              
        }

        public string GetConnection()
        {
            var con = _configuration.GetSection("DatabaseName").Value;
            return con;
        }

        public async Task<Movimento> CadastrarMovimentoAsync(Movimento movimento)
        {
            using var connection = new SqliteConnection(GetConnection());

            await connection.OpenAsync();

            movimento.IdMovimento = Guid.NewGuid();

            await connection.ExecuteAsync("INSERT INTO movimento (IdMovimento, IdContaCorrente, DataMovimento, TipoMovimento, Valor) VALUES(@IdMovimento, @IdContaCorrente, @DataMovimento, @TipoMovimento, @Valor)", movimento);

            if (connection.State == ConnectionState.Open)
            {
                await connection.CloseAsync();
            }

            return movimento;
        }

        
    }
}
