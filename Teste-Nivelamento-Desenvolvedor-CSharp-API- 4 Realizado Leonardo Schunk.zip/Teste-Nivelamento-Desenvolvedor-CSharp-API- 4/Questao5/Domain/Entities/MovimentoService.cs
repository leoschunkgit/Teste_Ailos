﻿using Questao5.Application.Commands.Requests;
using Questao5.Application.Commands.Responses;
using Questao5.Domain.Entities.Movimentacao;

namespace Questao5.Domain.Entities
{
    public class MovimentoService : IMovimentoService
    {
        private readonly IMovimentoCommandStore _commandStore;
        
        public MovimentoService(IMovimentoCommandStore commandStore)
        {
            _commandStore = commandStore;
        }

        public async Task<CadastrarMovimentoCommandResponse> CadastrarMovimentoAsync(CadastrarMovimentoCommandRequest request)
        {
            var newMovimento = new Movimento(request.idContaCorremte, DateTime.Now, request.tipoMovimento, request.valor);

            var response = await _commandStore.CadastrarMovimentoAsync(newMovimento);

            return response.MapResponse();
        }
    }
}
