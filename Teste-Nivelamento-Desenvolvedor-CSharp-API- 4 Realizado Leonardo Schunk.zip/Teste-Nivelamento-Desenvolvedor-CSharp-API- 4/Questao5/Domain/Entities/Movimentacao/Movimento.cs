﻿using Questao5.Application.Commands.Responses;

namespace Questao5.Domain.Entities.Movimentacao
{
    public class Movimento
    {
        public Guid IdMovimento { get; set; }
        public Guid IdContaCorrente { get; set; }
        public DateTime DataMovimento { get; set; }
        public string TipoMovimento { get; set; }
        public Decimal Valor { get; set; }

        public Movimento(Guid idMovimento, Guid idContaCorrente, DateTime dataMovimento, string tipoMovimento, Decimal valor)
        {
            IdMovimento = idMovimento;
            IdContaCorrente = idContaCorrente;
            DataMovimento = dataMovimento;
            TipoMovimento = tipoMovimento;
            Valor = valor;
        }

        public Movimento(Guid idContaCorrente, DateTime dataMovimento, string tipoMovimento, Decimal valor)
        {   
            IdContaCorrente = idContaCorrente;
            DataMovimento = dataMovimento;
            TipoMovimento = tipoMovimento;
            Valor = valor;
        }

        public CadastrarMovimentoCommandResponse MapResponse()
        {
            return new CadastrarMovimentoCommandResponse(IdMovimento, "Cadastrado com sucesso");
        }
    }
}
