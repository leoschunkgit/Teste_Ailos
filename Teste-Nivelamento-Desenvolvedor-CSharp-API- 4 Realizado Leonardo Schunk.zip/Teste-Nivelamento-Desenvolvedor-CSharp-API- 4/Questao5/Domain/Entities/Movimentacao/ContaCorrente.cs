﻿namespace Questao5.Domain.Entities.Movimentacao
{
    public class ContaCorrente
    {
        public Guid IdContaCorrente { get; private set; }
        public int Numero { get; private set; }
        public string Nome { get; private set; }
        public int Ativo { get; private set; }

        public ContaCorrente(Guid idContaCorrente, int numero, string nome, int ativo)
        {
            IdContaCorrente = idContaCorrente;
            Numero = numero;
            Nome = nome;
            Ativo = ativo;
        }
    }
}
