﻿using Questao5.Application.Commands.Requests;
using Questao5.Application.Commands.Responses;

namespace Questao5.Domain.Entities
{
    public interface IMovimentoService
    {
        Task<CadastrarMovimentoCommandResponse> CadastrarMovimentoAsync(CadastrarMovimentoCommandRequest request);
    }
}
