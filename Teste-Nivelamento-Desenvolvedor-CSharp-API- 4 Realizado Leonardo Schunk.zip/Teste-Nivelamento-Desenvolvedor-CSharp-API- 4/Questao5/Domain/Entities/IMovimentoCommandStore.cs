﻿using Questao5.Domain.Entities.Movimentacao;

namespace Questao5.Domain.Entities
{
    public interface IMovimentoCommandStore
    {
        Task<Movimento> CadastrarMovimentoAsync(Movimento movimento);
    }
}
