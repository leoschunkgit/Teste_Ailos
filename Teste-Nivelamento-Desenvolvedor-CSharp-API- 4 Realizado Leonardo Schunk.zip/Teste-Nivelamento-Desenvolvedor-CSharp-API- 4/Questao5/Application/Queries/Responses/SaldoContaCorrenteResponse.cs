﻿using Questao5.Application.Queries.Requests;

namespace Questao5.Application.Queries.Responses
{
    public class SaldoContaCorrenteResponse
    {
        public SaldoContaCorrenteConsulta SaldoContaCorrenteConsulta { get; set; }      
    }
}
