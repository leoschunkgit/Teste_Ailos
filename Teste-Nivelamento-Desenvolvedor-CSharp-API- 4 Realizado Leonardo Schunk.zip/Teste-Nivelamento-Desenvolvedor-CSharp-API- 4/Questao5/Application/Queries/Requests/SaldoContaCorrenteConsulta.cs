﻿using System.Globalization;

namespace Questao5.Application.Queries.Requests
{
    public class SaldoContaCorrenteConsulta
    {
        public string valor { get; set; }
        public string tipomovimento { get; set; }
        public int contaCorrenteAtivo {  get; set; }
        public string mensagem { get; set; }
        public string numeroContaCorrente { get; set; }
        public string nomeTitularContaCorrente { get; set; }
        public string dataConsulta { get; set; }

        public SaldoContaCorrenteConsulta()
        {
                
        }

        public SaldoContaCorrenteConsulta(string Valor, string TipoMovimento, int ContaCorrenteAtivo, string Mensagem, string NumeroContaCorrente, string NomeTitularContaCorrente, string DataConsulta)
        {
            valor = Valor;
            tipomovimento = TipoMovimento;
            contaCorrenteAtivo = ContaCorrenteAtivo;
            mensagem = Mensagem;
            numeroContaCorrente = NumeroContaCorrente;
            nomeTitularContaCorrente = NomeTitularContaCorrente;
            dataConsulta = DataConsulta;
        }
    }
}
