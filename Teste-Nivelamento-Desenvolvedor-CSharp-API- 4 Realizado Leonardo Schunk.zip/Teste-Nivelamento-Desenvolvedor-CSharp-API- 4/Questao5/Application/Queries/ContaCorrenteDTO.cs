﻿namespace Questao5.Application.Queries
{
    public class ContaCorrenteDTO
    {
        public int numero { get; set; }
        public string nome { get; set; } = string.Empty;
        public int ativo { get; set; }

        public ContaCorrenteDTO(int Numero, string Nome, int Ativo)
        {
            numero = Numero;
            nome = Nome;
            ativo = Ativo;
        }
    }
}
