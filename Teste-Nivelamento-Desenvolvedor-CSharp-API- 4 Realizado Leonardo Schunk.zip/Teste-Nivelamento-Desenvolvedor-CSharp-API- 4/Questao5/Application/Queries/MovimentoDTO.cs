﻿namespace Questao5.Application.Queries
{
    public class MovimentoDTO
    {
        public double valor { get; set; }
        public string tipomovimento { get; set; } = string.Empty;
        public int contaCorrenteAtivo { get; set; }
        public int numeroContaCorrente { get; set; }
        public string nomeTitularContaCorrente { get; set; } = string.Empty;
    }
}
