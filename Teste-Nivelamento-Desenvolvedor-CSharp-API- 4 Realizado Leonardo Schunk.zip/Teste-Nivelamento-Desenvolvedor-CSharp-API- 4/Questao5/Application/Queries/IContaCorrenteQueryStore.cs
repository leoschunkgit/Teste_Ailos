﻿namespace Questao5.Application.Queries
{
    public interface IContaCorrenteQueryStore
    {
        Task<string> VerificarIdContaCorrentePorIdAsync(Guid idcontacorrente);
        Task<string> VerificarIdContaCorrentePorIdAndAtivoAsync(Guid idcontacorrente);
    }
}
