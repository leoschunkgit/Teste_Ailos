﻿using Questao5.Application.Queries.Requests;

namespace Questao5.Application.Queries
{
    public interface IMovimentoQueryStore
    {
        Task<List<MovimentoDTO>> BuscarSaldoContaCorrenteAsync(SaldoContaCorrenteRequest request);
                
    }
}
