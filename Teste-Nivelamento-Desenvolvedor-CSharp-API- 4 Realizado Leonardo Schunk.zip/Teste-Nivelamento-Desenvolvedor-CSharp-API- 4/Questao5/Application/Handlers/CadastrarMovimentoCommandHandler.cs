﻿using MediatR;
using Questao5.Application.Commands.Requests;
using Questao5.Application.Commands.Responses;
using Questao5.Application.Queries;
using Questao5.Domain.Entities;

namespace Questao5.Application.Handlers
{
    public class CadastrarMovimentoCommandHandler : IRequestHandler<CadastrarMovimentoCommandRequest, CadastrarMovimentoCommandResponse>
    {   
        private readonly IContaCorrenteQueryStore _contaCorrenteQueryStore;
        private readonly IMovimentoService _movimentoService;
        
        public CadastrarMovimentoCommandHandler(IContaCorrenteQueryStore contaCorrenteQueryStore,
            IMovimentoService movimentoService)
        {   
            _contaCorrenteQueryStore = contaCorrenteQueryStore;
            _movimentoService = movimentoService;            
        }

        public async Task<CadastrarMovimentoCommandResponse> Handle(CadastrarMovimentoCommandRequest request, CancellationToken cancellationToken)
        {
            if (request.valor < 0 || (!request.tipoMovimento.Equals("C") && !request.tipoMovimento.Equals("D")))
                return new CadastrarMovimentoCommandResponse(Guid.Empty, "Erro");

            var contaCorrente = await _contaCorrenteQueryStore.VerificarIdContaCorrentePorIdAndAtivoAsync(request.idContaCorremte);
            if(!string.IsNullOrWhiteSpace(contaCorrente))
            {
                return await _movimentoService.CadastrarMovimentoAsync(request);                
            }
            else
            {
                return new CadastrarMovimentoCommandResponse(Guid.Empty, "Erro");
            }
        }
    }
}
