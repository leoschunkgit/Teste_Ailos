﻿using MediatR;
using Questao5.Application.Queries;
using Questao5.Application.Queries.Requests;
using Questao5.Application.Queries.Responses;

namespace Questao5.Application.Handlers
{
    public class SaldoContaCorrenteQueryHandler : IRequestHandler<SaldoContaCorrenteRequest, SaldoContaCorrenteResponse>
    {
        private readonly IMovimentoQueryStore _movimentoQueryStore;
        private readonly IContaCorrenteQueryStore _contaCorrenteQueryStore;
        
        public SaldoContaCorrenteQueryHandler(IMovimentoQueryStore movimentoQueryStore, IContaCorrenteQueryStore contaCorrenteQueryStore)
        {
            _movimentoQueryStore = movimentoQueryStore;
            _contaCorrenteQueryStore = contaCorrenteQueryStore;            
        }

        public async Task<SaldoContaCorrenteResponse> Handle(SaldoContaCorrenteRequest request, CancellationToken cancellationToken)
        {   
            string idcontacorrente = await _contaCorrenteQueryStore.VerificarIdContaCorrentePorIdAsync(request.idContaCorrente);
            if (string.IsNullOrWhiteSpace(idcontacorrente))
                return new SaldoContaCorrenteResponse() { SaldoContaCorrenteConsulta = new SaldoContaCorrenteConsulta { mensagem = "Apenas contas correntes cadastradas podem consultar o saldo" } };

            var movimentacaoSaldoContaCorrenteDto = await _movimentoQueryStore.BuscarSaldoContaCorrenteAsync(request);

            if (movimentacaoSaldoContaCorrenteDto.Count == 0)
                return new SaldoContaCorrenteResponse() { SaldoContaCorrenteConsulta = new SaldoContaCorrenteConsulta { valor = "R$0,00", mensagem = "Sua conta NÃO possui nenhuma movimentação" } };

            var itemMovimentacao = movimentacaoSaldoContaCorrenteDto.First();
            if (itemMovimentacao.contaCorrenteAtivo == 0)
                return new SaldoContaCorrenteResponse() { SaldoContaCorrenteConsulta = new SaldoContaCorrenteConsulta { mensagem = "Apenas contas correntes ativas podem consultar o saldo" } };

            SaldoContaCorrenteConsulta retornoConsulta = new SaldoContaCorrenteConsulta();

            var valorTotalCredito = movimentacaoSaldoContaCorrenteDto.Where(x => x.tipomovimento.ToUpper() == "C").Sum(x => x.valor);
            var valorTotalDebito = movimentacaoSaldoContaCorrenteDto.Where(x => x.tipomovimento.ToUpper() == "D").Sum(x => x.valor);

            retornoConsulta.numeroContaCorrente = itemMovimentacao.numeroContaCorrente.ToString();
            retornoConsulta.nomeTitularContaCorrente = itemMovimentacao.nomeTitularContaCorrente;
            retornoConsulta.dataConsulta = DateTime.Now.ToString();
            retornoConsulta.valor = (valorTotalCredito - valorTotalDebito).ToString();
            retornoConsulta.mensagem = "Sua conta possui movimentações";
            retornoConsulta.contaCorrenteAtivo = itemMovimentacao.contaCorrenteAtivo;

            return new SaldoContaCorrenteResponse() { SaldoContaCorrenteConsulta = retornoConsulta };            
        }       
    }
}
