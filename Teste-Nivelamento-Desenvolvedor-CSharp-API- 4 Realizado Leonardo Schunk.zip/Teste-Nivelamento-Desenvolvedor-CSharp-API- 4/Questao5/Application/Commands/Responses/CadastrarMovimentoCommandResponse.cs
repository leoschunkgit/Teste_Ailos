﻿namespace Questao5.Application.Commands.Responses
{
    public class CadastrarMovimentoCommandResponse
    {
        Guid idMovimento {  get; set; }
        string mensagem { get; set; }

        public CadastrarMovimentoCommandResponse()
        {
            
        }

        public CadastrarMovimentoCommandResponse(Guid IdMovimento, string Mensagem)
        {
            idMovimento = IdMovimento;
            mensagem = Mensagem;
        }        
    }
}
