﻿using MediatR;
using Questao5.Application.Commands.Responses;

namespace Questao5.Application.Commands.Requests
{
    public class CadastrarMovimentoCommandRequest : IRequest<CadastrarMovimentoCommandResponse>
    {
        public Decimal valor { get; set; }
        public Guid idContaCorremte { get; set; }
        public string tipoMovimento { get; set; }

        public CadastrarMovimentoCommandRequest()
        {
                
        }

        public CadastrarMovimentoCommandRequest(Decimal Valor, Guid IdContaCorremte, string TipoMovimento)
        {
            valor = Valor;
            idContaCorremte = IdContaCorremte;    
            tipoMovimento  = TipoMovimento;
        }
    }
}
