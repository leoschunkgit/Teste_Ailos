SELECT a.assunto as ASSUNTO, a.ano as ANO, Count(1) AS QUANTIDADE
FROM atendimentos a
GROUP BY a.ano, a.assunto
HAVING Count(1) > 3
ORDER BY a.ano DESC, 3 DESC;
